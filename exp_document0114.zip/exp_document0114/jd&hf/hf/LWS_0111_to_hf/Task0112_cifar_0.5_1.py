import os
from itertools import product

ds = "cifar10"
pr = 0.5
mo = "resnet"

lw_seq = [1]
lr = 1e-2
wd = 1e-2
seed_seq = [101, 202, 303, 404, 505]


for lw, seed in list(product(lw_seq, seed_seq)):
    os.system("python main-cv_sgd_best.py -ds {} -pr {} -mo {} -lo lws -lw {} -lr {} -wd {} -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed {} -gpu 2".format(ds, pr, mo, lw, lr, wd, seed))

