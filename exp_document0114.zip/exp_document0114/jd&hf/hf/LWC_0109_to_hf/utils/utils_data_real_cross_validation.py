import os
import numpy as np
import torch
import torch.utils.data
from torch.utils.data import Dataset
from scipy.io import loadmat
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold


class RealDataset(Dataset):
    def __init__(self, X, y):
        self.X = X
        self.y = y
        assert X.shape[0] == y.shape[0]

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        X = self.X[idx]
        y = self.y[idx]
        return (X, y)


class RealIdxDataset(Dataset):
    def __init__(self, X, y):
        self.X = X
        self.y = y
        assert X.shape[0] == y.shape[0]

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        X = self.X[idx]
        y = self.y[idx]
        return (X, y, idx)


def generate_real_cross_validation_splits(dataname, datadir):
    datapath = os.path.join(datadir, "{}.mat".format(dataname))
    dt = loadmat(datapath)
    X = dt["data"]
    partial_y = dt["partial_target"]
    y = dt["target"]

    if type(partial_y) is np.ndarray:
        partial_y = partial_y.transpose()
    else:
        partial_y = partial_y.toarray().transpose()
    if type(y) is np.ndarray:
        y = y.transpose()
    else:
        y = y.toarray().transpose()

    X = np.float32(X)
    partial_y = np.float32(partial_y)
    y = np.float32(y)

    # from one-hot encoder to multiclass label
    label = y.argmax(axis=1)

    cross_validation_splits = {}
    skf = StratifiedKFold(n_splits=10, shuffle=False)
    for idx, (train_index, test_index) in enumerate(skf.split(X, label)):
        cross_validation_splits[idx] = {}
        # split
        cross_validation_splits[idx]["train_X"] = X[train_index]
        cross_validation_splits[idx]["test_X"] = X[test_index]
        cross_validation_splits[idx]["train_partial_y"] = partial_y[
            train_index]
        cross_validation_splits[idx]["test_partial_y"] = partial_y[test_index]
        cross_validation_splits[idx]["train_y"] = y[train_index]
        cross_validation_splits[idx]["test_y"] = y[test_index]
        # normalize
        scaler = StandardScaler()
        cross_validation_splits[idx]["train_X"] = scaler.fit_transform(
            cross_validation_splits[idx]["train_X"])
        cross_validation_splits[idx]["test_X"] = scaler.transform(
            cross_validation_splits[idx]["test_X"])

    return cross_validation_splits


def generate_real_dataloader(batch_size, train_X, train_partial_y, train_y,
                             test_X, test_y):
    ordinary_train_dataset = RealDataset(train_X, train_y)
    train_eval_loader = torch.utils.data.DataLoader(
        dataset=ordinary_train_dataset,
        batch_size=len(ordinary_train_dataset),
        shuffle=False,
        drop_last=False,
        num_workers=0)

    train_dataset = RealIdxDataset(train_X, train_partial_y)
    train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                               batch_size=batch_size,
                                               shuffle=True,
                                               drop_last=True,
                                               num_workers=0)

    ordinary_test_dataset = RealDataset(test_X, test_y)
    test_eval_loader = torch.utils.data.DataLoader(
        dataset=ordinary_test_dataset,
        batch_size=len(ordinary_test_dataset),
        shuffle=False,
        drop_last=False,
        num_workers=0)

    num_features = train_X.shape[1]
    num_classes = train_y.shape[1]

    return (train_loader, train_eval_loader, test_eval_loader, train_partial_y,
            num_features, num_classes)
