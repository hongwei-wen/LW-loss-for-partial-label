import os
import glob
import numpy as np
import pandas as pd
from itertools import product

loss = 'lws'
ds_seq = ["mnist", "kmnist", "fashion", "cifar10"]
partial_rate_seq = [0.1, 0.3, 0.5]
seed_seq = [101]
model_seq = ['mlp', 'cnn', 'linear', 'resnet']

lw_seq = [1.0, 2.0, 4.0]
lr_seq = [1e-1, 5e-2, 1e-2, 5e-3, 1e-3]
wd_seq = [1e-6, 1e-5, 1e-4, 1e-3, 1e-2]

with open("Summarize.csv", "w") as f:
    f.writelines("ds,partial_rate,model,lw,lr,wd,avg,std,length\n")

all_results = []
for model, ds, partial_rate in product(model_seq, ds_seq, partial_rate_seq):
    if ds == "cifar10":
        if model not in ["cnn", 'resnet']:
            continue
    else:
        if model not in ['mlp', 'linear']:
            continue

    for lw, lr, wd in product(lw_seq, lr_seq, wd_seq):
        results = []
        for seed in seed_seq:
            pattern = os.path.join(
                "results_cv_best",
                "Res-sgd_{}_{}_{}_{}_{}_{}_{}_*_{}.csv".format(
                    ds, partial_rate, model, loss, lw, lr, wd, seed))
            if len(glob.glob(pattern)) < 1:
                continue
            path = glob.glob(pattern)[-1]
            log = pd.read_csv(path)
            if log.shape[0] != 250 + 1:
                continue
            acc = log["test_acc"].iloc[-10:].mean()
            results.append(acc)
        if len(results) > 0:
            results = np.array(results)
            avg = results.mean()
            std = results.std()
            length = len(results)
            all_results.append(
                [ds, partial_rate, model, lw, lr, wd, avg, std, length])
            print("{},{},{},{},{},{},{:.4f},{:.4f},{}".format(
                ds, partial_rate, model, lw, lr, wd, avg, std, length))
            with open("Summarize.csv", "a") as f:
                f.writelines("{},{},{},{},{},{},{:.4f},{:.4f},{}\n".format(
                    ds, partial_rate, model, lw, lr, wd, avg, std, length))

all_results = pd.DataFrame(all_results)
all_results.columns = [
    'dataset', 'partial_rate', 'model', 'lw', 'lr', 'wd', 'avg', 'std',
    'length'
]
best_idx = all_results.groupby(['dataset', 'partial_rate',
                                'model']).idxmax()["avg"]
print(all_results.iloc[best_idx])
all_results.iloc[best_idx].to_csv("Summarize_best.csv")

