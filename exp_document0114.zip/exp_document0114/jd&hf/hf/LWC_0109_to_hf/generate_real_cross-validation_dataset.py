import os
from scipy.io import savemat
from utils.utils_data_real_cross_validation import generate_real_cross_validation_splits

data_dir = "real"
save_dir = "real_crossvalidated"
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

dataname_seq = [
    "BirdSong", "FG-NET", "lost", "Mirflickr", "MSRCv2", "SoccerPlayer",
    "YahooNews"
]
for dataname in dataname_seq:
    cross_validation_splits = generate_real_cross_validation_splits(
        dataname, data_dir)
    for key in cross_validation_splits.keys():
        save_name = "{}_{:02d}.mat".format(dataname, key)
        save_path = os.path.join(save_dir, save_name)
        savemat(save_path, cross_validation_splits[key])
