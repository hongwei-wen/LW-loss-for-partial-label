import os
from itertools import product

ds = "mnist"
pr = 0.3
mo = "mlp"

lw_seq = [1, 2, 4]
lr_seq = [1e-1, 5e-2, 1e-2, 5e-3, 1e-3]
wd_seq = [1e-6, 1e-5, 1e-4, 1e-3, 1e-2]


for lw, lr, wd in list(product(lw_seq, lr_seq, wd_seq))[50:75]:
    os.system("python main-cv_sgd_best.py -ds {} -pr {} -mo {} -lo lws -lw {} -lr {} -wd {} -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 101 -gpu 3".format(ds, pr, mo, lw, lr, wd))
