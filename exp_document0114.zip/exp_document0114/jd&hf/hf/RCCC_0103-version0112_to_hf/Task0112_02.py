import os

os.system("python main-cv_sgd_best.py -ds kmnist -pr 0.5 -mo mlp -lo lws -lw 2 -lr 1e-1 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 101 -gpu 3")

os.system("python main-cv_sgd_best.py -ds kmnist -pr 0.5 -mo mlp -lo lws -lw 2 -lr 1e-1 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 202 -gpu 3")

os.system("python main-cv_sgd_best.py -ds kmnist -pr 0.5 -mo mlp -lo lws -lw 2 -lr 1e-1 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 303 -gpu 3")

os.system("python main-cv_sgd_best.py -ds kmnist -pr 0.5 -mo mlp -lo lws -lw 2 -lr 1e-1 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 404 -gpu 3")

os.system("python main-cv_sgd_best.py -ds kmnist -pr 0.5 -mo mlp -lo lws -lw 2 -lr 1e-1 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 505 -gpu 3")

os.system("python main-cv_sgd_best.py -ds mnist -pr 0.1 -mo mlp -lo lws -lw 2 -lr 5e-2 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 101 -gpu 3")

os.system("python main-cv_sgd_best.py -ds mnist -pr 0.1 -mo mlp -lo lws -lw 2 -lr 5e-2 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 202 -gpu 3")

os.system("python main-cv_sgd_best.py -ds mnist -pr 0.1 -mo mlp -lo lws -lw 2 -lr 5e-2 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 303 -gpu 3")

os.system("python main-cv_sgd_best.py -ds mnist -pr 0.1 -mo mlp -lo lws -lw 2 -lr 5e-2 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 404 -gpu 3")

os.system("python main-cv_sgd_best.py -ds mnist -pr 0.1 -mo mlp -lo lws -lw 2 -lr 5e-2 -wd 1e-3 -ldr 0.5 -lds 50 -bs 256 -ep 250 -seed 505 -gpu 3")
