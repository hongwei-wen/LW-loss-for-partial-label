import numpy as np
import torch
from sklearn.preprocessing import OneHotEncoder
import os
from scipy.special import comb
import hashlib
import errno


def generate_uniform_cv_candidate_labels(train_labels, partial_rate):
    if torch.min(train_labels) > 1:
        raise RuntimeError('testError')
    elif torch.min(train_labels) == 1:
        train_labels = train_labels - 1

    K = torch.max(train_labels) - torch.min(train_labels) + 1
    n = train_labels.shape[0]
    number = torch.tensor([
        comb(K, i + 1) * partial_rate**(i + 1) *
        (1 - partial_rate)**(int(K) - (i + 1)) for i in range(K - 1)
    ]).float()
    cardinality = number.sum()
    frequency_dis = number / cardinality
    prob_dis = torch.zeros(K - 1)  # tensor of K-1
    for i in range(K - 1):
        if i == 0:
            prob_dis[i] = frequency_dis[i]
        else:
            prob_dis[i] = frequency_dis[i] + prob_dis[i - 1]

    random_n = torch.from_numpy(np.random.uniform(0, 1,
                                                  n)).float()  # tensor: n
    mask_n = torch.ones(n)  # n is the number of train_data
    partialY = torch.zeros(n, K)
    partialY[torch.arange(n), train_labels] = 1.0

    temp_num_partial_train_labels = 0  # save temp number of partial train_labels

    for j in range(n):  # for each instance
        for jj in range(K - 1):  # 0 to K-2
            if random_n[j] <= prob_dis[jj] and mask_n[j] == 1:
                temp_num_partial_train_labels = jj + 1  # decide the number of partial train_labels
                mask_n[j] = 0

        temp_num_fp_train_labels = temp_num_partial_train_labels - 1
        candidates = torch.from_numpy(np.random.permutation(
            K.item())).long()  # because K is tensor type
        candidates = candidates[candidates != train_labels[j]]
        temp_fp_train_labels = candidates[:temp_num_fp_train_labels]

        partialY[
            j, temp_fp_train_labels] = 1.0  # fulfill the partial label matrix
    print("Finish Generating Candidate Label Sets!\n")
    return partialY


def binarize_class(y):
    label = y.reshape(len(y), -1)
    enc = OneHotEncoder(categories='auto')
    enc.fit(label)
    label = enc.transform(label).toarray().astype(np.float32)
    label = torch.from_numpy(label)
    return label


def partialize(y, y0, t, p):
    new_y = y.clone()
    n, c = y.shape[0], y.shape[1]
    avgC = 0

    if t == 'binomial':
        for i in range(n):
            row = new_y[i, :]
            row[np.where(np.random.binomial(1, p, c) == 1)] = 1
            while torch.sum(row) == 1:
                row[np.random.randint(0, c)] = 1
            avgC += torch.sum(row)
            new_y[i] = row / torch.sum(row)

    if t == 'pair':
        P = np.eye(c)
        for idx in range(0, c - 1):
            P[idx, idx], P[idx, idx + 1] = 1, p
        P[c - 1, c - 1], P[c - 1, 0] = 1, p
        for i in range(n):
            row = new_y[i, :]
            idx = y0[i]
            row[np.where(np.random.binomial(1, P[idx, :], c) == 1)] = 1
            avgC += torch.sum(row)
            new_y[i] = row / torch.sum(row)

    avgC = avgC / n
    return new_y, avgC


def check_integrity(fpath, md5):
    if not os.path.isfile(fpath):
        return False
    md5o = hashlib.md5()
    with open(fpath, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            md5o.update(chunk)
    md5c = md5o.hexdigest()
    if md5c != md5:
        return False
    return True


def download_url(url, root, filename, md5):
    import urllib.request

    root = os.path.expanduser(root)
    fpath = os.path.join(root, filename)

    try:
        os.makedirs(root)
    except OSError as e:
        if e.errno == errno.EEXIST:
            pass
        else:
            raise

    if os.path.isfile(fpath) and check_integrity(fpath, md5):
        print('Using downloaded and verified file: ' + fpath)
    else:
        print('Downloading ' + url + ' to ' + fpath)
        urllib.request.urlretrieve(url, fpath)
