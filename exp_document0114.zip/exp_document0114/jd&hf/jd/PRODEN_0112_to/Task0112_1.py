import os
from itertools import product

ds = "mnist"
partial_rate_seq = [0.1, 0.3, 0.5]
seed_seq = [101]

model = "lenet"
lr_seq = [1e-1, 1e-2, 1e-3]
wd_seq = [1e-6, 1e-5, 1e-4, 1e-3, 1e-2]
decaystep = 500
decayrate = 1.0

for seed, partial_rate, lr, wd in list(product(seed_seq, partial_rate_seq, lr_seq, wd_seq))[0:22]:
    os.system(
        "CUDA_VISIBLE_DEVICES=0 python main.py -ds {} -partial_rate {} -model {} -lr {} -wd {} -decaystep {} -decayrate {} -bs 256 -ep 500 -seed {}"
        .format(ds, partial_rate, model, lr, wd, decaystep, decayrate, seed))
