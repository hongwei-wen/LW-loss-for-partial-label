import os
import glob
import numpy  as np
import pandas as pd
from itertools import product

ds_seq = ["mnist", "kmnist", "fashion", "cifar10"]
partial_rate_seq = [0.1, 0.3, 0.5]
seed_seq = [101, 202, 303, 404, 505]

save_path = "Summarize.csv"
with open(save_path, "w") as f:
    f.writelines("ds,partial_rate,model,avg,std,length\n")

for ds, partial_rate in product(ds_seq, partial_rate_seq):
    if ds == "cifar10":
        model_seq = ["convnet", "resnet"]
    else:
        model_seq = ["mlp", "linear"]
    for model in model_seq:
        results = []
        for seed in seed_seq:
            pattern = os.path.join("results", "Res_{}_{}_{}_*_{}.csv".format(ds, partial_rate, model, seed))
            assert len(glob.glob(pattern)) == 1
            path = glob.glob(pattern)[-1]
            log = pd.read_csv(path)
            if log.shape[0] != 500:
                continue
            acc = log["test_acc"].iloc[-10:].mean()
            results.append(acc)
        results = np.array(results)
        avg = results.mean()
        std = results.std()
        length = len(results)
        with open(save_path, "a") as f:
            f.writelines("{},{},{},{:.06f},{:.06f},{}\n".format(ds, partial_rate, model, avg, std, length))
        print(ds, partial_rate, model, avg, std, length)


save_path = "Log.csv"
with open(save_path, "w") as f:
    f.writelines("ds,partial_rate,model,seed,acc\n")

for ds, partial_rate in product(ds_seq, partial_rate_seq):
    if ds == "cifar10":
        model_seq = ["convnet", "resnet"]
    else:
        model_seq = ["mlp", "linear"]
    for model in model_seq:
        for seed in seed_seq:
            pattern = os.path.join("results", "Res_{}_{}_{}_*_{}.csv".format(ds, partial_rate, model, seed))
            assert len(glob.glob(pattern)) == 1
            path = glob.glob(pattern)[-1]
            log = pd.read_csv(path)
            acc = log["test_acc"].iloc[-10:].mean()
            with open(save_path, "a") as f:
                f.writelines("{},{},{},{},{:.06f}\n".format(ds, partial_rate, model, seed, acc))
